// Selection sort in C++

#include <iostream>
using namespace std;

void printArray(int array[], int size)
{
  for (int i = 0; i < size; i++)
  {
    cout << array[i] << " ";
  }
  cout << endl;
}

void selectionSort(int array[], int size)
{
  for (int step = 0; step < size - 1; step++)
  {
    int min_idx = step;
    for (int i = step + 1; i < size; i++)
    {
      // To sort in descending order, change > to < in this line.
      // Select the minimum element in each loop.

      if (array[i] < array[min_idx]) // acending
        // if (array[i] > array[min_idx]) // decending order
        min_idx = i;
    }

    // put min at the correct position
    int temp = array[min_idx];
    array[min_idx] = array[step];
    array[step] = temp;
  }
}

// driver code
int main()
{
  int data[] = {20, 12, 10, 15, 2};
  int size = sizeof(data) / sizeof(data[0]);

  cout << "Given Array :\n";
  printArray(data, size);

  selectionSort(data, size);

  cout << "Sorted array in Acsending Order:\n";
  printArray(data, size);
}