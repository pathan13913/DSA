//        ****************  Author :  Tashin.Parvez  *************************\
//        ****************  Updated:    13-07-23     *************************\

#include <bits/stdc++.h>
#define CRACKED return 0;
#define nl endl // NewLine
using namespace std;

int smallerElement(stack<int> sp)
{
    stack<int> s = sp;
    


}

int main()
{
    stack<int> s;
    s.push(2);
    s.push(1);
    s.push(4);
    s.push(3);
    stack<int> ans;
    for (int i = 0; i < s.size(); i++)
    {
    }

    CRACKED;
}
