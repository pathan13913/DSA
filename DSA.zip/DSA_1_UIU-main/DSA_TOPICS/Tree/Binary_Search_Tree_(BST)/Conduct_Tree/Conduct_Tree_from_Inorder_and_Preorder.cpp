//        ****************  Author :  Tashin.Parvez  *************************\
//        ****************  Updated:    18-08-23     *************************\

#include <bits/stdc++.h>
#define    CRACKED   return 0;
#define    nl        endl              // NewLine
#define    null        NULL
using  namespace std;

int32_t main()
{   
    
    CRACKED;
}